<?php

namespace App\Contracts\Repositories;

interface DeliveryZipCodeRepositoryInterface extends RepositoryInterface
{

}
