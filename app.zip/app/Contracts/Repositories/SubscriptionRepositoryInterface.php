<?php

namespace App\Contracts\Repositories;

interface SubscriptionRepositoryInterface extends RepositoryInterface
{

}
