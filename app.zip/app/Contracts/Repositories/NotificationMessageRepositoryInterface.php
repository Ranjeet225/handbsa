<?php

namespace App\Contracts\Repositories;

interface NotificationMessageRepositoryInterface extends RepositoryInterface
{

}
