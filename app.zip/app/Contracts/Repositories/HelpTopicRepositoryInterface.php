<?php

namespace App\Contracts\Repositories;

interface HelpTopicRepositoryInterface extends RepositoryInterface
{

}
