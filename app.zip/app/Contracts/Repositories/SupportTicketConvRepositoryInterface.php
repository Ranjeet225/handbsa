<?php

namespace App\Contracts\Repositories;

interface SupportTicketConvRepositoryInterface extends RepositoryInterface
{

}
