<?php

namespace App\Contracts\Repositories;

interface ShopFollowerRepositoryInterface extends RepositoryInterface
{

}
