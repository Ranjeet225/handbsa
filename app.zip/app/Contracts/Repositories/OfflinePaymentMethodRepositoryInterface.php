<?php

namespace App\Contracts\Repositories;

interface OfflinePaymentMethodRepositoryInterface extends RepositoryInterface
{

}
