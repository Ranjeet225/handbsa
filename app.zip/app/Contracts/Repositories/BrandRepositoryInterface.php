<?php

namespace App\Contracts\Repositories;

interface BrandRepositoryInterface extends RepositoryInterface
{

}
