<?php

namespace App\Contracts\Repositories;

interface SupportTicketRepositoryInterface extends RepositoryInterface
{

}
