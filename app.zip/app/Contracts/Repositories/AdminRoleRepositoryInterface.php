<?php

namespace App\Contracts\Repositories;

interface AdminRoleRepositoryInterface extends RepositoryInterface
{

}
