<?php

namespace App\Contracts\Repositories;

interface ProductSeoRepositoryInterface extends RepositoryInterface
{

}
