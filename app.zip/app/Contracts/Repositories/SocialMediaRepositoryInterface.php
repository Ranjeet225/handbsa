<?php

namespace App\Contracts\Repositories;

interface SocialMediaRepositoryInterface extends RepositoryInterface
{

}
