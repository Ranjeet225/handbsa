<?php

namespace App\Contracts\Repositories;

interface OrderStatusHistoryRepositoryInterface extends RepositoryInterface
{

}
