<?php

namespace App\Contracts\Repositories;

interface ShippingMethodRepositoryInterface extends RepositoryInterface
{

}
