<?php

namespace App\Contracts\Repositories;

interface FlashDealProductRepositoryInterface extends RepositoryInterface
{

}
