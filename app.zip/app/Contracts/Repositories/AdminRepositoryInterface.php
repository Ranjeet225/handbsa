<?php

namespace App\Contracts\Repositories;

interface AdminRepositoryInterface extends RepositoryInterface
{

}
