<?php

namespace App\Contracts\Repositories;

interface ShopRepositoryInterface extends RepositoryInterface
{

}
