<?php

namespace App\Contracts\Repositories;

interface DeliveryCountryCodeRepositoryInterface extends RepositoryInterface
{

}
