<?php

namespace App\Contracts\Repositories;

interface ShippingAddressRepositoryInterface extends RepositoryInterface
{

}
