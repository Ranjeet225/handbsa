<?php

namespace App\Contracts\Repositories;

interface CurrencyRepositoryInterface extends RepositoryInterface
{

}
