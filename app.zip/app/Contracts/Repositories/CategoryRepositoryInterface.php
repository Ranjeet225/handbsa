<?php

namespace App\Contracts\Repositories;

interface CategoryRepositoryInterface extends RepositoryInterface
{

}
