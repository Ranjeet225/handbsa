<?php

namespace App\Enums\ViewPaths\Admin;

enum PrioritySetup
{
    const INDEX = [
        URI => '',
        VIEW => 'admin-views.business-settings.priority-setup.index',
    ];
}
