<?php

namespace App\Enums\ViewPaths\Admin;

enum EnvironmentSettings
{
    const VIEW = [
        URI => 'environment-setup',
        VIEW => 'admin-views.business-settings.environment-index'
    ];

}
