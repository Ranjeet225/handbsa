<?php

namespace App\Enums\ViewPaths\Admin;

enum GoogleMapAPI
{
    const VIEW = [
        URI => 'map-api',
        VIEW => 'admin-views.business-settings.map-api.index',
    ];

}
