<?php

namespace App\Enums\ViewPaths\Admin;

enum InhouseProductSale
{

    const VIEW = [
        URI => 'inhouse-product-sale',
        VIEW => 'admin-views.report.inhouse-product-sale'
    ];

}
