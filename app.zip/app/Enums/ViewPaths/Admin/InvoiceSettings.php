<?php

namespace App\Enums\ViewPaths\Admin;

enum InvoiceSettings
{
    const VIEW = [
        URI => '/',
        VIEW => 'admin-views.business-settings.invoice-settings.index'
    ];

}
