<?php

namespace App\Enums\ViewPaths\Admin;

enum Recaptcha
{
    const VIEW = [
        URI => 'recaptcha',
        VIEW => 'admin-views.business-settings.recaptcha-index',
    ];

}
