<?php

namespace App\Enums\ViewPaths\Admin;

enum Auth
{
    const ADMIN_LOGIN = 'admin-views.auth.login';
}
