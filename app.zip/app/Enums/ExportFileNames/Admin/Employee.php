<?php

namespace App\Enums\ExportFileNames\Admin;

enum Employee
{
    const EMPLOYEE_ROLE_LIST = 'Employee-Role-List.xlsx';
}
