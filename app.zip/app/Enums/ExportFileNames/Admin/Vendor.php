<?php

namespace App\Enums\ExportFileNames\Admin;

enum Vendor
{
    const EXPORT_XLSX = 'Seller-list.xlsx';
    const ORDER_LIST_EXPORT = 'Order-List.xlsx';
}
