<?php

namespace App\Enums\ExportFileNames\Admin;

enum Brand
{
    const EXPORT_XLSX = 'Brand-list.xlsx';
}
