<?php

namespace App\Enums\ExportFileNames\Admin;

enum Category
{
    const CATEGORY_LIST_XLSX = 'category-list.xlsx';
    const SUB_CATEGORY_LIST_XLSX = 'sub-category-list.xlsx';
    const SUB_SUB_CATEGORY_LIST_XLSX = 'sub-sub-category-list.xlsx';

}
