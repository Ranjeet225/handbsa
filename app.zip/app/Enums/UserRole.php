<?php

namespace App\Enums;

enum UserRole
{
    const ADMIN = 'admin';
    const EMPLOYEE = 'employee';
}
