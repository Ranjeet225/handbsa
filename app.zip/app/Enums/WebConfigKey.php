<?php

namespace App\Enums;

enum WebConfigKey
{
    const PAGINATION_LIMIT = 'pagination_limit';
}
